﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NCI.DCEG.BCRA.Engine;
using NCI.DCEG.BCRA.ConsoleSample;

namespace WebGail
{
    public partial class _Default : Page
    {
       
       
    }
}